//
// HW #14: using map to store, accumulate and lookup (key, value) pairs:
//

#include <iostream>
#include <string>

using namespace std;

int main()
{
  string key;
  int value;

  // 
  // input (key, value) pairs and accumulate into map:
  //
  cout << "Enter key or #> ";
  cin >> key;

  while (key != "#")
  {
    cout << "Enter value> ";
    cin >> value;


    //
    // TODO: use map to store / accumulate (key, value) pair:
    //
    

    cout << "Enter key or #> ";
    cin >> key;
  }

  //
  // now allow user to search for key and retrieve value:
  //
  cout << endl;
  cout << "Enter key to lookup, or #> ";
  cin >> key;

  while (key != "#")
  {
     
    //
    // TODO: use map to lookup key...
    //
    

    cout << "Enter key to lookup, or #> ";
    cin >> key;
  }

  //
  // done:
  //
  return 0;
}
